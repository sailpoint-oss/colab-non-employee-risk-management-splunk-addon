This is an add-on powered by the Splunk Add-on Builder.

#Binary File Declaration
bin/ta_sailpoint_non_employee_risk_management_auditevent_add_on/aob_py3/markupsafe/_speedups.cpython-37m-x86_64-linux-gnu.so
bin/ta_sailpoint_non_employee_risk_management_auditevent_add_on/aob_py3/yaml/_yaml.cpython-37m-x86_64-linux-gnu.so